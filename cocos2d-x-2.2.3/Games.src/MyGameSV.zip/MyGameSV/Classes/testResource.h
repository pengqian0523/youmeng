#ifndef _TEST_RESOURCE_H_
#define _TEST_RESOURCE_H_

static const char s_pPathGrossini[]       = "Images/grossini.png";



#endif
