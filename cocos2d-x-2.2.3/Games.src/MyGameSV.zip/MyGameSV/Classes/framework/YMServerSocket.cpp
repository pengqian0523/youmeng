﻿#include "YMServerSocket.h"
#include "YMIconv.h"
#include "YMDebugCmd.h"

YMServerSocket YMServerSocket::m_ins;
YMServerSocket *YMServerSocket::getIns() {
    return &m_ins;
}

YMServerSocket::YMServerSocket():
    tcpSocket(new YMTcpSocket()) {
    iStamp = 1;
    isConnected = false;
    YMTcpSocket::Init();
    int ret = tcpSocket->Create(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if (ret) {
        CCLOG("Create socket:success,ret:%d\n", ret);
    } else {
        CCLOG("Create socket:fail,ret:%d", ret);
    }
}

YMServerSocket::~YMServerSocket() {
    YMTcpSocket::Clean();
    close();
    if ( tcpSocket ) {
        delete tcpSocket;
        tcpSocket = NULL;
    }
}

string YMServerSocket::int2String(unsigned int val) {
    char buff[25];
    sprintf(buff, "0x%04X", val);
    return std::string(buff);
}

int YMServerSocket::chars2Int(char chars[]) {
    int iVal = 0;
    for (int i = 0; i < 4; i++) {
        iVal += (chars[i] & 0xFF) << ((3 - i) * 8);
    }
    return iVal;
}

void YMServerSocket::int2Chars(char *chars, int val, int start) {
    chars[start++] = (char)((val >> 24) & 0xFF);
    chars[start++] = (char)((val >> 16) & 0xFF);
    chars[start++] = (char)((val >> 8) & 0xFF);
    chars[start++] = (char)((val >> 0) & 0xFF);
}

int YMServerSocket::close() {
    isConnected = false;
    this->dispatchEvent(new YMSocketEvent(YMSocketEvent::EVENT_SOCKET_CLOSE, 0));
    return tcpSocket->Close();
}

int YMServerSocket::Recv(char* buf, int len, int flags) {
    return tcpSocket->Recv(buf, len, flags);
}


int YMServerSocket::GetError() {
    return tcpSocket->GetError();
}


void YMServerSocket::getKey(int cmd, int stamp , int needKeylen, char buffer[]) {
    int byteKey = (((needKeylen & cmd) + (stamp ^ cmd)) % 0xFF);
    for (int i = 0; i < needKeylen; i++) {
        cmd -=  (((byteKey * needKeylen) ^ stamp) % 0xFF);
        stamp -=  byteKey;
        byteKey = ((cmd % 0xFF));
        buffer[i] = byteKey;
    }
}


void YMServerSocket::hasError() {
    this->dispatchEvent(new YMSocketEvent(YMSocketEvent::EVENT_SOCKET_ERROR, GetError()));
};

void YMServerSocket::Handler() {
    char fromip[200];
	char sendmsg[2048];
	char recvmsg[2048];
	unsigned long recv_sz=2048;
	//memset(buff,0,4);
    int len;
    while (1) {
        len = YMServerSocket::getIns()->Accept(*YMServerSocket::getIns()->tcpSocket,fromip);
        if (len > 0) {
            YMServerSocket::getIns()->Recv(recvmsg, recv_sz, 0);

			sprintf(sendmsg,"%s",recvmsg);
			YMServerSocket::getIns()->Send(sendmsg,strlen(sendmsg)+1);
        } else {
            YMServerSocket::getIns()->hasError();
            CCLOG("threadHandler errorCode: %d" , YMServerSocket::getIns()->GetError());
        }
    }
}

bool YMServerSocket::Bind(unsigned short port){
	return tcpSocket->Bind(port);
}

bool YMServerSocket::Listen(int backlog){
	return tcpSocket->Listen(backlog);
}

bool YMServerSocket::Accept(YMTcpSocket& s, char*fromip){
	return tcpSocket->Accept(s,fromip);
}

bool YMServerSocket::Send(char sendmsg[],int size){
	return tcpSocket->Send(sendmsg,size,0);
}