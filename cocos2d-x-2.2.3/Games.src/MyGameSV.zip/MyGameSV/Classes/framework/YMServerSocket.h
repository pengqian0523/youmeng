﻿#ifndef __YMServerSocket_H__
#define __YMServerSocket_H__

#ifdef WIN32
#include "platform/third_party/win32/pthread/pthread.h"
#else
#include <pthread.h>
#endif
//#include "../cocos2dx/platform/third_party/emscripten/libz/zlib.h"
#include <stdlib.h>
#include "YMEventDispatcher.h"
#include "YMTcpSocket.h"
#include "YMSocketEvent.h"
#include "YMSocketDataEvent.h"
#include "YMSocketData.h"

class YMServerSocket: public YMEventDispatcher {
public:
    static YMServerSocket *getIns();
private:
    static YMServerSocket m_ins;
private:
    YMServerSocket();
    virtual ~YMServerSocket();
public:
    int close();
    int GetError();
	bool Bind(unsigned short port);
	bool Listen(int backlog=50);
	bool Accept(YMTcpSocket& s, char*fromip);
	bool Send(char sendmsg[],int size);
	void Handler();
private:
    
public:
	bool isConnected;
private:
    unsigned int iStamp;
    pthread_t threadId;
    pthread_attr_t threadAttr;
    YMTcpSocket *tcpSocket;
    int chars2Int(char chars[]);
    void int2Chars(char *chars, int val, int start = 0);
	string int2String(unsigned int val);
    int Recv(char* buf, int len, int flags = 0);
    void getKey(int cmd, int stamp, int needKeylen, char buffer[]);
    void encrypt(char buffer[], int size, int cmd, int stamp);
	void hasError();
	
};

#endif