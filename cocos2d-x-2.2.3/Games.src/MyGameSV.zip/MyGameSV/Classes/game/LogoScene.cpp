#include "LogoScene.h"
#include "YMLabelTTF.h"
#include "YMCommonLabelTTF.h"
#include "gameLayer.h"
#include "YMSocketData.h"
#include "YMServerSocket.h"
#include "myServer.h"
#include <stdlib.h>
#define FONT_SZ "fonts/arial.ttf"

LogoScene::LogoScene(){
	flag=0;
}

LogoScene::~LogoScene(){

}

void LogoScene::onEnter(){
	CCScene::onEnter();

	UILayer *pLayer=UILayer::create();
	UILayout *mylayout = dynamic_cast<UILayout *>(GUIReader::shareReader()->widgetFromJsonFile("logoscene/logoscene.json"));
	this->addChild(pLayer);
	pLayer->addWidget(mylayout);

	myServer *pmyServer = myServer::create();
}

void LogoScene::hand0x0101Handler(YMEvent *ymevt){
	CCLOG("aaaaa");
}

void LogoScene::getKey(int cmd, int stamp , int needKeylen, char buffer[]) {
	int byteKey = (((needKeylen & cmd) + (stamp ^ cmd)) % 0xFF);
	for (int i = 0; i < needKeylen; i++) {
		cmd -=  (((byteKey * needKeylen) ^ stamp) % 0xFF);
		stamp -=  byteKey;
		byteKey = ((cmd % 0xFF));
		buffer[i] = byteKey;
	}
}

void LogoScene::encrypt(char buffer[], int size, int cmd, int stamp) {
	int len = (size > 128) ? 128 : size;
	char keys[128];
	getKey(cmd, stamp, len, keys);
	for (int i = 0; i < len; i++) {
		buffer[i] = buffer[i] ^ keys[i];
	}
}