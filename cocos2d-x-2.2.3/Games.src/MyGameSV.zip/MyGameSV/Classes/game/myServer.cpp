#include "myServer.h"
#include "YMLabelTTF.h"
#include "YMCommonLabelTTF.h"
#include "gameLayer.h"
#include "YMSocketData.h"
#include "YMServerSocket.h"

#define MAXSIZE 2048
#define PORT 6000
#define FONT_SZ "fonts/arial.ttf"

myServer::myServer(){
	
}

myServer::~myServer(){

}

myServer *myServer::create(){
	myServer *pRet = new myServer();
	if(pRet && pRet->init()){
		pRet->autorelease();
	}else{
		CC_SAFE_DELETE(pRet);
	}
	return pRet;
}

bool myServer::init(){
// 	char fromip[300];
// 	char recvmsg[MAXSIZE], sendmsg[MAXSIZE]; 
// 	YMServerSocket *pYMServerSocket = new YMServerSocket();
// 	if(!pYMServerSocket->Init()){
// 		CCLOG("init TcpSocket faild");
// 	}else{
// 		CCLOG("init TcpSocket sucess");
// 	}
// 
// 	if(pYMServerSocket->Create(AF_INET, SOCK_STREAM, 0)==-1){
// 		CCLOG("cretae Socket faild");
// 	}else{
// 		CCLOG("cretae Socket sucess");
// 	}
// 
// 	if(!pYMServerSocket->Bind(6666)){
// 		CCLOG("bind faild");
// 	}else{
// 		CCLOG("bind sucess");
// 	}
// 
// 	if(!pYMServerSocket->Listen()){
// 		CCLOG("listen faild");
// 	}else{
// 		CCLOG("listen sucess");
// 	}
// 
// 	while(1){
// 		if(!pYMServerSocket->Accept(*pYMServerSocket,fromip)){
// 			CCLOG("accpt sucess");
// 		}
// 
// 		memset(recvmsg, 0, MAXSIZE);
// 		memset(sendmsg, 0, MAXSIZE);
// 		//��������
// 		sprintf(sendmsg,"server to you");
// 		if(pYMServerSocket->Send(sendmsg,strlen(sendmsg)+1,0)!=-1){
// 			CCLOG("send sucess");
// 		}
// 
// 		if(pYMServerSocket->Recv(recvmsg,MAXSIZE,0)!=-1){
// 			CCLOG("%s",recvmsg);
// 		}
// 	}
// 
// 	pYMServerSocket->Close();

	YMServerSocket::getIns()->Bind(6666);
	YMServerSocket::getIns()->Listen();
	YMServerSocket::getIns()->Handler();
// 	YMSocketData data("{\"id\":\"132112\"}");
// 	if (!YMClientSocket::getIns()->getIns()->isConnected) {
// 		if (YMClientSocket::getIns()->connect("192.168.1.104", PORT) != SOCKET_ERROR) {
// 			
// 		}
// 	} 

	return 0;
}